
import json
import boto3

lambda_client = boto3.client("lambda")

PLANNER_FUNCTION = "planner-agent"


def invoke_planner(files):

    payload = {
        "files": files
    }

    try:
        response = lambda_client.invoke(
            FunctionName=PLANNER_FUNCTION,
            InvocationType="RequestResponse",  # IMPORTANT for debugging
            Payload=json.dumps(payload)
        )

        result = response["Payload"].read().decode("utf-8")

        print("Planner Triggered Response:")
        print(result)

        return result

    except Exception as e:
        print("Planner Invoke Error:", str(e))
        return str(e)


def lambda_handler(event, context):

    print("Incoming Event:")
    print(json.dumps(event))

    # ----------------------------
    # SAFE PARSING (VERY IMPORTANT)
    # ----------------------------
    try:
        if "body" in event:
            body = json.loads(event["body"])
        else:
            body = event
    except Exception as e:
        print("Parse error:", str(e))
        return {
            "statusCode": 400,
            "body": "Invalid JSON body"
        }

    # ----------------------------
    # GitHub ping
    # ----------------------------
    if "zen" in body:
        return {
            "statusCode": 200,
            "body": "Ping OK"
        }

    # ----------------------------
    # Extract files
    # ----------------------------
    files = []

    for commit in body.get("commits", []):
        files.extend(commit.get("added", []))
        files.extend(commit.get("modified", []))
        files.extend(commit.get("removed", []))

    files = list(set(files))

    print("Changed Files:", files)

    # ----------------------------
    # Trigger planner
    # ----------------------------
    planner_response = ""

    if files:
        print("Triggering planner-agent...")
        planner_response = invoke_planner(files)
    else:
        print("No files found")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "files": files,
            "planner_response": planner_response
        })
    }