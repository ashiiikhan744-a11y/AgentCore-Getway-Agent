import json
import boto3

sqs = boto3.client("sqs")

PERF_QUEUE = "https://sqs.us-east-1.amazonaws.com/xxxxxxxx/perf-queue"
SCRIPT_QUEUE = "https://sqs.us-east-1.amazonaws.com/xxxxxxx/script-queue"
EXEC_QUEUE = "https://sqs.us-east-1.amazonaws.com/xxxxxxxxx/execution-queue"


def send(queue, body):
    sqs.send_message(
        QueueUrl=queue,
        MessageBody=json.dumps(body)
    )


def lambda_handler(event, context):

    path = event["rawPath"]
    body = json.loads(event["body"])

    if path in ["/mcp/perf-agent", "/perf-agent"]:
        send(PERF_QUEUE, body)

    elif path in ["/mcp/script-agent", "/script-agent"]:
        send(SCRIPT_QUEUE, body)

    elif path in ["/mcp/execution-agent", "/execution-agent"]:
        send(EXEC_QUEUE, body)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Task queued successfully",
            "route": path
        })
    }