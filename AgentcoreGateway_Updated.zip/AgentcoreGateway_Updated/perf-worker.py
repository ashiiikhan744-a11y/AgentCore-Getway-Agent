import os
import time
import json
import base64
import urllib3

http = urllib3.PoolManager()

# ================================
# ENV
# ================================
SPEEDCURVE_KEY = os.getenv("SPEEDCURVE_KEY")
SITE_ID = os.getenv("SPEEDCURVE_SITE_ID")

DATADOG_API_KEY = os.getenv("DATADOG_API_KEY")
DATADOG_APP_KEY = os.getenv("DATADOG_APP_KEY")
DATADOG_SITE = os.getenv("DATADOG_SITE", "datadoghq.com")

METRIC_PREFIX = "speedcurve"


# ================================
# AUTH HEADER
# ================================
def speedcurve_headers():
    token = base64.b64encode(f"{SPEEDCURVE_KEY}:".encode()).decode()
    return {
        "Authorization": "Basic " + token
    }


# ================================
# GET LATEST TEST
# ================================
def get_latest_test():

    start_time = int(time.time()) - 3600  # last 1 hour

    url = f"https://api.speedcurve.com/v1/tests?site_id={SITE_ID}&start_timestamp={start_time}"

    print("Fetching tests:", url)

    res = http.request(
        "GET",
        url,
        headers=speedcurve_headers(),
        timeout=20
    )

    if res.status != 200:
        print("SpeedCurve error:", res.data)
        return None

    data = json.loads(res.data.decode("utf-8"))

    tests = data.get("data") or data.get("tests") or []

    if not tests:
        return None

    for t in tests:
        if t.get("status") == 0:
            return t

    return None

# ================================
# DATADOG PUSH
# ================================
def send_metric(metric, value, tags):

    try:
        value = float(value)
    except:
        return

    url = f"https://api.{DATADOG_SITE}/api/v1/series"

    payload = {
        "series": [
            {
                "metric": metric,
                "points": [[int(time.time()), value]],
                "type": "gauge",
                "tags": tags
            }
        ]
    }

    res = http.request(
        "POST",
        url,
        body=json.dumps(payload),
        headers={
            "Content-Type": "application/json",
            "DD-API-KEY": DATADOG_API_KEY,
            "DD-APPLICATION-KEY": DATADOG_APP_KEY
        },
        timeout=20
    )

    print("Datadog:", res.status, res.data)

def get_label_from_url(url):

    if not url:
        return "unknown"

    if "sephora.com/" == url or url.endswith(".com/"):
        return "Home"

    if "foundation" in url:
        return "PLP"

    if "fragrance" in url:
        return "Fragrance"

    if "perfume" in url:
        return "Deluxe Perfume"

    return "unknown"

def trigger_speedcurve_test():

    url = "https://api.speedcurve.com/v1/deploys"

    payload = {
        "site_id": SITE_ID,
        "note": "Lambda trigger"
    }

    res = http.request(
        "POST",
        url,
        body=json.dumps(payload),
        headers={
            "Content-Type": "application/json",
            **speedcurve_headers()
        },
        timeout=20
    )

    print("Trigger Status:", res.status)
    print("Trigger Response:", res.data)

    data = json.loads(res.data.decode("utf-8"))

    # ✅ HANDLE: already running test
    if res.status == 403:
        print("Test already running, using existing deploy_id")
        return data.get("deploy_id")

    # ❌ real failure
    if res.status != 200:
        return None

    deploy_id = data.get("id") or data.get("deploy_id")

    print("Deploy ID:", deploy_id)

    return deploy_id
# ================================
# MAIN
# ================================
def process():

    # ================================
    # STEP 1: Trigger test
    # ================================
    deploy_id = trigger_speedcurve_test()

    if not deploy_id:
        return {"status": "trigger_failed"}

    print("Using deploy_id:", deploy_id)
    print("Waiting for test to complete...")

    # ================================
    # STEP 2: Poll until complete
    # ================================
    test = None

    for i in range(8):   # ~160 sec max

        print(f"Checking attempt {i+1}...")

        test = get_latest_test()

        if test and test.get("status") == 0:
            print("Test completed!")
            break

        time.sleep(20)

    if not test:
        return {"status": "test_not_ready"}

    print("TEST:", json.dumps(test))

    # ================================
    # STEP 3: Extract metrics
    # ================================
    lcp = test.get("largest_contentful_paint", 0)
    cls = test.get("cumulative_layout_shift", 0)
    tti = test.get("time_to_interactive", 0)

    url = test.get("url")

    # ================================
    # STEP 4: Label mapping
    # ================================
    label = get_label_from_url(url)

    print("LABEL:", label)
    print("METRICS:", lcp, cls, tti)

    if lcp == 0 and cls == 0 and tti == 0:
        return {"status": "empty_metrics"}

    # ================================
    # STEP 5: Datadog tags
    # ================================
    tags = [
        f"site_id:{SITE_ID}",
        f"url:{url}",
        f"label:{label}",
        f"browser:{test.get('browser')}",
        f"region:{test.get('region')}"
    ]

    # ================================
    # STEP 6: Send to Datadog
    # ================================
    send_metric(METRIC_PREFIX + ".lcp", lcp, tags)
    send_metric(METRIC_PREFIX + ".cls", cls, tags)
    send_metric(METRIC_PREFIX + ".tti", tti, tags)

    # ================================
    # FINAL RESPONSE
    # ================================
    return {
        "status": "success",
        "metrics": {
            "lcp": lcp,
            "cls": cls,
            "tti": tti
        },
        "label": label,
        "deploy_id": deploy_id
    }
# ================================
# HANDLER
# ================================
def lambda_handler(event, context):

    try:
        result = process()
        return {
            "statusCode": 200,
            "body": json.dumps(result)
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": str(e)
        }