# ==========================================================
# FILE: execution-worker.py
# PURPOSE:
# Real ECS Fargate K6 runner
# Gateway Target:
# execution-agent-target
# ==========================================================

import json
import boto3

# ----------------------------------------------------------
# REPLACE THESE VALUES
# ----------------------------------------------------------
AWS_REGION = "us-east-1"
CLUSTER_NAME = "my-cluster"
TASK_DEFINITION = "k6-task"

SUBNETS = [
    "subnet-0aaf2f3d55100517d",
    "subnet-0fec356d104da0227"
]

SECURITY_GROUPS = [
    "sg-01d07eba2e86d4af2"
]

# ----------------------------------------------------------
# AWS Client
# ----------------------------------------------------------
ecs = boto3.client("ecs", region_name=AWS_REGION)


# ----------------------------------------------------------
# Main Handler
# ----------------------------------------------------------
def lambda_handler(event, context):

    print("Incoming Event:")
    print(json.dumps(event))

    try:
        response = ecs.run_task(
            cluster=CLUSTER_NAME,
            launchType="FARGATE",
            taskDefinition=TASK_DEFINITION,
            count=1,
            networkConfiguration={
                "awsvpcConfiguration": {
                    "subnets": SUBNETS,
                    "securityGroups": SECURITY_GROUPS,
                    "assignPublicIp": "ENABLED"
                }
            }
        )

        task_arn = response["tasks"][0]["taskArn"]

        return {
            "passed": True,
            "status": "started",
            "taskArn": task_arn
        }

    except Exception as e:

        return {
            "passed": False,
            "error": str(e)
        }