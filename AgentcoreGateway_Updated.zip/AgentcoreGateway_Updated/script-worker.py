import json
import base64
import urllib3
import os

http = urllib3.PoolManager()

# ENV VARIABLES (NO HARDCODED VALUES)
SLACK_WEBHOOK_URL = os.environ.get("SLACK_WEBHOOK_URL")
JIRA_BASE_URL = os.environ.get("JIRA_BASE_URL")
JIRA_EMAIL = os.environ.get("JIRA_EMAIL")
JIRA_API_TOKEN = os.environ.get("JIRA_API_TOKEN")
JIRA_PROJECT_KEY = os.environ.get("JIRA_PROJECT_KEY", "KAN")


# ----------------------------------------------------------
# Slack Alert
# ----------------------------------------------------------
def send_slack(message):

    if not SLACK_WEBHOOK_URL:
        return {
            "passed": False,
            "error": "Missing Slack webhook"
        }

    try:
        response = http.request(
            "POST",
            SLACK_WEBHOOK_URL,
            body=json.dumps({"text": message}),
            headers={"Content-Type": "application/json"},
            timeout=15
        )

        return {
            "passed": True,
            "status_code": response.status
        }

    except Exception as e:
        return {
            "passed": False,
            "error": str(e)
        }


# ----------------------------------------------------------
# Jira Ticket
# ----------------------------------------------------------
def create_jira(summary, description):

    if not JIRA_BASE_URL or not JIRA_EMAIL or not JIRA_API_TOKEN:
        return {
            "passed": False,
            "error": "Missing Jira configuration"
        }

    try:
        auth = base64.b64encode(
            f"{JIRA_EMAIL}:{JIRA_API_TOKEN}".encode()
        ).decode()

        url = JIRA_BASE_URL + "/rest/api/3/issue"

        payload = {
            "fields": {
                "project": {"key": JIRA_PROJECT_KEY},
                "summary": summary,
                "description": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [
                                {"type": "text", "text": description}
                            ]
                        }
                    ]
                },
                "issuetype": {"name": "Task"}
            }
        }

        response = http.request(
            "POST",
            url,
            body=json.dumps(payload),
            headers={
                "Authorization": "Basic " + auth,
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            timeout=15
        )

        return {
            "passed": True,
            "status_code": response.status,
            "data": response.data.decode("utf-8")
        }

    except Exception as e:
        return {
            "passed": False,
            "error": str(e)
        }


# ----------------------------------------------------------
# Main Handler (UNCHANGED)
# ----------------------------------------------------------
def lambda_handler(event, context):

    print("Incoming Event:")
    print(json.dumps(event))

    issue = event.get("issue", "").lower()

    if "slack" in issue:
        return send_slack(event.get("message", "Pipeline update"))

    if "jira" in issue:
        return create_jira(
            event.get("summary", "Pipeline Issue"),
            event.get("description", "Auto created issue")
        )

    return {
        "slack": send_slack("Automation workflow executed"),
        "jira": create_jira(
            "Automation Run",
            "Triggered from workflow"
        )
    }