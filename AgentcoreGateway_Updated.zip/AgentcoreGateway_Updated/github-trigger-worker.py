import json
import os
import boto3

lambda_client = boto3.client("lambda")

PLANNER_FUNCTION = os.environ.get("PLANNER_FUNCTION", "planner-agent")


def invoke_planner_async(payload):
    """
    Fire-and-forget invocation so GitHub does NOT time out.
    """
    try:
        lambda_client.invoke(
            FunctionName=PLANNER_FUNCTION,
            InvocationType="Event",  # ASYNC — critical
            Payload=json.dumps(payload)
        )
        print("Planner invoked asynchronously")
        return "Planner invoked async"

    except Exception as e:
        print("Planner Invoke Error:", str(e))
        return str(e)


def lambda_handler(event, context):
    print("Incoming Event:")
    print(json.dumps(event))

    # ----------------------------
    # SAFE PARSING
    # ----------------------------
    try:
        if "body" in event:
            body = json.loads(event["body"])
        else:
            body = event
    except Exception as e:
        print("Parse error:", str(e))
        return {
            "statusCode": 400,
            "body": "Invalid JSON body"
        }

    # ----------------------------
    # GitHub ping event
    # ----------------------------
    if "zen" in body:
        return {
            "statusCode": 200,
            "body": "Ping OK"
        }

    # ----------------------------
    # Extract changed files
    # ----------------------------
    files = []
    for commit in body.get("commits", []):
        files.extend(commit.get("added", []))
        files.extend(commit.get("modified", []))
        files.extend(commit.get("removed", []))

    files = list(set(files))
    print("Changed Files:", files)

    # ----------------------------
    # Build planner payload
    # ----------------------------
    repo = body.get("repository") or {}
    planner_payload = {
        "files": files,
        "head_sha": body.get("after", ""),
        "base_sha": body.get("before", ""),
        "repository": repo,
        "ref": body.get("ref", "")
    }

    # ----------------------------
    # Trigger planner asynchronously
    # ----------------------------
    if files:
        print("Triggering planner-agent asynchronously...")
        invoke_planner_async(planner_payload)
    else:
        print("No changed files detected")

    # ----------------------------
    # IMMEDIATE RESPONSE TO GITHUB
    # ----------------------------
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Webhook received",
            "files": files
        })
    }
