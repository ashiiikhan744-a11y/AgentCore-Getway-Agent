# ==========================================================
# RCA agent Lambda — GitHub compare + Bedrock narrative
# Gateway tool name (example): rca-agent-target___analyze
#
# AWS Lambda Option A: put this file at ZIP root as rca_worker.py
# Handler: rca_worker.lambda_handler
# ==========================================================

import json
import logging
import os
import sys

_root = os.path.dirname(os.path.abspath(__file__))
for _p in (_root, os.path.abspath(os.path.join(_root, ".."))):
    if os.path.isdir(os.path.join(_p, "agents_common")):
        sys.path.insert(0, _p)
        break
else:
    sys.path.insert(0, _root)

import urllib3

from agents_common.otel_setup import init_otel

logger = logging.getLogger()
logger.setLevel(logging.INFO)

http = urllib3.PoolManager()
_tracer = init_otel(os.environ.get("OTEL_SERVICE_NAME", "rca-worker"))


def _github_compare(owner, repo, base_sha, head_sha, token):
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com").rstrip("/")
    url = f"{api}/repos/{owner}/{repo}/compare/{base_sha}...{head_sha}"
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"token {token}"
    resp = http.request("GET", url, headers=headers, timeout=30.0)
    if resp.status != 200:
        return None, resp.status, resp.data.decode("utf-8", errors="replace")
    return json.loads(resp.data.decode("utf-8")), resp.status, None


def _bedrock_rca(files, regression_context, compare_json):
    import boto3

    client = boto3.client("bedrock-runtime")
    commits = compare_json.get("commits", []) if compare_json else []
    commit_summaries = []
    for c in commits[:30]:
        commit_summaries.append(
            {
                "sha": (c.get("sha") or "")[:8],
                "message": (c.get("commit") or {}).get("message", "")[:500],
                "author": ((c.get("commit") or {}).get("author") or {}).get("name"),
            }
        )

    prompt = f"""You are an RCA engineer. Given metric regression signals, changed files, and recent commits, explain likely root cause and concrete next steps.

Changed files: {json.dumps(files)}
Regression analysis: {json.dumps(regression_context)}
Commit summaries: {json.dumps(commit_summaries)}
Total commits in range: {compare_json.get("total_commits") if compare_json else 0}

Respond with JSON only:
{{
  "summary": "one paragraph",
  "likely_causes": ["..."],
  "recommended_actions": ["..."],
  "commits_to_review": ["sha or message fragments"]
}}
"""

    resp = client.invoke_model(
        modelId=os.environ.get("RCA_MODEL_ID", "amazon.nova-micro-v1:0"),
        body=json.dumps(
            {
                "messages": [{"role": "user", "content": [{"text": prompt}]}],
                "inferenceConfig": {"maxTokens": 800, "temperature": 0.3},
            }
        ),
    )
    body = json.loads(resp["body"].read())
    text = body["output"]["message"]["content"][0]["text"]
    try:
        start = text.index("{")
        end = text.rindex("}") + 1
        return json.loads(text[start:end])
    except (ValueError, json.JSONDecodeError):
        return {"summary": text, "likely_causes": [], "recommended_actions": [], "commits_to_review": []}


def lambda_handler(event, context):
    print("Incoming Event:", json.dumps(event))

    token = os.environ.get("GITHUB_TOKEN", "")
    repo_full = event.get("repo_full_name") or os.environ.get("DEFAULT_REPO_FULL_NAME", "")
    base_sha = event.get("base_sha") or ""
    head_sha = event.get("head_sha") or ""
    files = event.get("files") or []
    regression_context = event.get("regression_context") or {}

    if not repo_full or "/" not in repo_full:
        return {"passed": False, "error": "repo_full_name required"}

    owner, repo = repo_full.split("/", 1)
    if not base_sha or not head_sha:
        return {
            "passed": False,
            "error": "base_sha and head_sha required for compare",
            "rca": {"summary": "Insufficient git range; provide webhook before/after SHAs."},
        }

    compare = None
    gh_err = None
    if _tracer:
        with _tracer.start_as_current_span("rca.github_compare"):
            compare, status, err_body = _github_compare(owner, repo, base_sha, head_sha, token)
            if compare is None:
                gh_err = f"github_{status}:{err_body[:500]}"
    else:
        compare, status, err_body = _github_compare(owner, repo, base_sha, head_sha, token)
        if compare is None:
            gh_err = f"github_{status}:{err_body[:500]}"

    rca = _bedrock_rca(files, regression_context, compare or {})

    out = {
        "passed": True,
        "github_error": gh_err,
        "compare": {
            "ahead_by": compare.get("ahead_by") if compare else None,
            "behind_by": compare.get("behind_by") if compare else None,
            "status": compare.get("status") if compare else None,
            "files_changed": compare.get("files") if compare else None,
        },
        "rca": rca,
    }
    print(json.dumps(out))
    return out
