import json
import time
import urllib.parse
import urllib3


def query_scalar_avg(http, site, api_key, app_key, metric_query, from_ts, to_ts):
    """
    Run a Datadog v1 query; return last scalar value from first series or None.
    metric_query example: avg:speedcurve.lcp{*}
    """
    q = urllib.parse.quote(metric_query, safe="")
    url = f"https://api.{site}/api/v1/query?from={from_ts}&to={to_ts}&query={q}"
    resp = http.request(
        "GET",
        url,
        headers={
            "DD-API-KEY": api_key,
            "DD-APPLICATION-KEY": app_key,
        },
        timeout=30.0,
    )
    if resp.status != 200:
        return None, resp.data.decode("utf-8", errors="replace")
    data = json.loads(resp.data.decode("utf-8"))
    series = data.get("series") or []
    if not series:
        return None, "no_series"
    pts = series[0].get("pointlist") or []
    for pair in reversed(pts):
        if len(pair) >= 2 and pair[1] is not None:
            return float(pair[1]), None
    return None, "no_points"


def latest_window():
    now = int(time.time())
    return now - 900, now
