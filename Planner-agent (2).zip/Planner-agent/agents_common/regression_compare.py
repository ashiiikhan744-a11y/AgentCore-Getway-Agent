from agents_common.thresholds import rule_for_metric


def evaluate_regression(baseline_metrics, current_metrics, config):
    """
    baseline_metrics / current_metrics: dict metric_name -> float
    Returns dict with regression bool, per-metric deltas, reasons.
    """
    deltas = {}
    reasons = []
    worst = 0.0

    for name, current in (current_metrics or {}).items():
        if current is None:
            continue
        base = (baseline_metrics or {}).get(name)
        if base is None:
            continue
        try:
            current_f = float(current)
            base_f = float(base)
        except (TypeError, ValueError):
            continue

        rule = rule_for_metric(config, name)
        rel_pct = float(rule["relative_pct"])
        direction = rule["direction"]
        abs_floor = float(rule["abs_floor"])

        delta = current_f - base_f
        deltas[name] = {
            "baseline": base_f,
            "current": current_f,
            "delta": delta,
            "delta_pct": _pct_change(base_f, current_f),
        }

        if abs(delta) < abs_floor:
            continue

        reg = False
        if base_f == 0:
            reg = current_f > abs_floor
        else:
            pct_change = (current_f - base_f) / abs(base_f) * 100.0
            if direction == "lower_is_better":
                reg = pct_change > rel_pct
            else:
                reg = pct_change < -rel_pct

        if reg:
            reasons.append(f"{name} regressed ({direction}): {base_f:.4g} -> {current_f:.4g}")
            worst = max(worst, abs(_pct_change(base_f, current_f)))

    return {
        "regression": len(reasons) > 0,
        "reasons": reasons,
        "metrics_delta": deltas,
        "severity": "high" if worst > 40 else ("medium" if worst > 20 else "low"),
    }


def _pct_change(base, current):
    if base == 0:
        return 0.0
    return (current - base) / abs(base) * 100.0
