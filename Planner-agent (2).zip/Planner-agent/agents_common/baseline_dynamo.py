import json
import time
import boto3


def _table():
    return boto3.resource("dynamodb").Table(_table_name())


def _table_name():
    import os
    n = os.environ.get("BASELINE_TABLE_NAME")
    if not n:
        raise ValueError("BASELINE_TABLE_NAME must be set for baseline persistence")
    return n


def baseline_key(repo_full_name, branch_or_ref):
    ref = branch_or_ref or "default"
    if ref.startswith("refs/heads/"):
        ref = ref.replace("refs/heads/", "")
    return f"{repo_full_name}#{ref}"


def get_baseline(repo_key):
    try:
        resp = _table().get_item(Key={"repo_key": repo_key})
    except Exception:
        return None
    item = resp.get("Item")
    if not item:
        return None
    raw = item.get("baseline_metrics_json")
    if raw:
        try:
            item["baseline_metrics"] = json.loads(raw)
        except json.JSONDecodeError:
            item["baseline_metrics"] = {}
    return item


def put_baseline(repo_key, metrics, head_sha, extra=None):
    item = {
        "repo_key": repo_key,
        "baseline_metrics_json": json.dumps(metrics),
        "head_sha": head_sha or "",
        "updated_at": int(time.time()),
    }
    if extra:
        item["extra_json"] = json.dumps(extra)
    _table().put_item(Item=item)
    return item


def delete_baseline(repo_key):
    _table().delete_item(Key={"repo_key": repo_key})
