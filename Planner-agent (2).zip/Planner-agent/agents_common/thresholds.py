import json
import os
from copy import deepcopy


DEFAULT_METRIC_RULE = {
    "relative_pct": 15.0,
    "direction": "lower_is_better",
    "abs_floor": 0.01,
}


def load_threshold_config():
    raw = os.environ.get("REGRESSION_THRESHOLDS_JSON")
    if raw:
        return json.loads(raw)
    path = os.environ.get(
        "REGRESSION_THRESHOLDS_PATH",
        os.path.join(os.path.dirname(__file__), "..", "config", "regression_thresholds.yaml"),
    )
    path = os.path.abspath(path)
    if os.path.isfile(path) and path.endswith(".yaml"):
        try:
            import yaml  # type: ignore
        except ImportError:
            return _default_config_from_env_only()
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    if os.path.isfile(path) and path.endswith(".json"):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return _default_config_from_env_only()


def _default_config_from_env_only():
    return {
        "metrics": {
            "speedcurve.lcp": deepcopy(DEFAULT_METRIC_RULE),
            "speedcurve.cls": {
                "relative_pct": 20.0,
                "direction": "lower_is_better",
                "abs_floor": 0.001,
            },
            "speedcurve.tti": deepcopy(DEFAULT_METRIC_RULE),
        },
        "anomaly_hint_with_bedrock": False,
    }


def rule_for_metric(config, metric_name):
    metrics = config.get("metrics") or {}
    rule = metrics.get(metric_name)
    if not rule:
        return dict(DEFAULT_METRIC_RULE)
    out = dict(DEFAULT_METRIC_RULE)
    out.update(rule)
    return out
