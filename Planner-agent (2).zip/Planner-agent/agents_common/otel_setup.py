import functools
import logging
import os

logger = logging.getLogger(__name__)


def init_otel(service_name: str):
    """
    Initialize OTEL tracer when OTLP endpoint env vars are set.
    No-op if OpenTelemetry is not installed or endpoints are unset.
    """
    endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or os.environ.get(
        "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT"
    )
    if not endpoint:
        return None

    try:
        from opentelemetry import trace
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    except ImportError:
        logger.warning("OpenTelemetry SDK not installed; skipping init")
        return None

    resource = Resource.create(
        {
            "service.name": service_name,
            "deployment.environment": os.environ.get("ENVIRONMENT", "dev"),
        }
    )
    provider = TracerProvider(resource=resource)
    exporter = OTLPSpanExporter()
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)

    return trace.get_tracer(__name__)


def traced(tracer, name: str):
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            if tracer is None:
                return fn(*args, **kwargs)
            with tracer.start_as_current_span(name):
                return fn(*args, **kwargs)

        return wrapper

    return decorator
